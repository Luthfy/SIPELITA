package id.digilabyte.sipelita.model.response;

public class UpdateProfileResponse {
}
