package id.digilabyte.sipelita.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import id.digilabyte.sipelita.R;

public class ContactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
    }
}
