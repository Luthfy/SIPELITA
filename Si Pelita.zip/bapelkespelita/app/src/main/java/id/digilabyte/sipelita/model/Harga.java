package id.digilabyte.sipelita.model;

public class Harga {
}
