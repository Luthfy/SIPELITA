package id.digilabyte.sipelita.constant;

public class Base {
    public static final String DIGILABYTE_BASE_URL = "http://bapelkes.live.gahar.xyz/";
}
